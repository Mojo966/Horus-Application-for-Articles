import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import Controls from './components/Controls';
import InputSection from './components/InputSection';
import OutputSection from './components/OutputSection';
import Footer from './components/Footer';
import { ContentType, ParsedArticle, GeneratedArticle } from './types';
import { parseRawInput } from './utils/parser';
import { generateArticleContent } from './services/geminiService';
import { API_KEY_ERROR_MESSAGE } from './constants';

const HorusEyeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 100 60" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M5,30 Q50,0 95,30 Q50,60 5,30 Z" />
        <circle cx="50" cy="30" r="12" fill="currentColor" />
        <path d="M50,42 V55 L40,58" />
        <path d="M95,30 C90,45 80,55 75,58" />
    </svg>
);

const App: React.FC = () => {
  const [rawInput, setRawInput] = useState<string>('');
  const [contentType, setContentType] = useState<ContentType>(ContentType.News);
  const [generatedArticles, setGeneratedArticles] = useState<GeneratedArticle[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const isApiKeySet = !!process.env.API_KEY;

  const handleUpdateArticleImage = useCallback((articleId: number, newImageUrl: string) => {
    setGeneratedArticles(prevArticles =>
      prevArticles.map(article =>
        article.id === articleId ? { ...article, imageUrl: newImageUrl } : article
      )
    );
  }, []);

  const handleGenerate = useCallback(async () => {
    if (!isApiKeySet) {
      setError(API_KEY_ERROR_MESSAGE);
      return;
    }

    const parsedData = parseRawInput(rawInput);
    if (parsedData.length === 0) {
      setError("Please enter valid article data in the specified format.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedArticles([]);

    try {
      const newArticles: GeneratedArticle[] = [];
      for (let i = 0; i < parsedData.length; i++) {
          const articleData = parsedData[i];
          const { html, imageUrl, metaDescription, metaKeywords, slug } = await generateArticleContent(articleData, contentType);
          newArticles.push({ 
            id: i, 
            html, 
            title: articleData.title, 
            imageUrl, 
            metaDescription,
            metaKeywords,
            slug
          });
      }
      setGeneratedArticles(newArticles);
    } catch (e) {
      console.error(e);
      if (e instanceof Error) {
        setError(`An error occurred while generating content: ${e.message}. Check the console for details.`);
      } else {
        setError("An unknown error occurred while generating content. Check the console for details.");
      }
    } finally {
      setIsLoading(false);
    }
  }, [rawInput, contentType, isApiKeySet]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6">
        <div className="flex flex-col items-center gap-4 my-4">
            <div className="horus-logo-pulse p-2">
                <HorusEyeIcon className="h-20 w-20 text-cyan-400" />
            </div>
            <h2 className="font-extrabold text-4xl text-gray-100 tracking-wider text-center" style={{ textShadow: '2px 2px 8px rgba(0, 255, 255, 0.5)' }}>
                أداة حورس للمقالات المخصصة
            </h2>
        </div>
        {error && (
            <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded-lg relative" role="alert">
                <strong className="font-bold">خطأ: </strong>
                <span className="block sm:inline">{error}</span>
                 <button onClick={() => setError(null)} className="absolute top-0 bottom-0 left-0 px-4 py-3" aria-label="Close">
                    <span className="text-2xl">×</span>
                </button>
            </div>
        )}
        <Controls
          contentType={contentType}
          setContentType={setContentType}
          onGenerate={handleGenerate}
          isLoading={isLoading}
          isDisabled={!rawInput.trim() || !isApiKeySet}
        />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-grow min-h-[500px]">
          <InputSection rawInput={rawInput} setRawInput={setRawInput} />
          <OutputSection articles={generatedArticles} isLoading={isLoading} onImageUpdate={handleUpdateArticleImage} setError={setError} />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;
