import React from 'react';
import { ContentType } from '../types';
import { CONTENT_TYPE_OPTIONS } from '../constants';
import LoadingIndicator from './LoadingIndicator';

interface ControlsProps {
  contentType: ContentType;
  setContentType: (type: ContentType) => void;
  onGenerate: () => void;
  isLoading: boolean;
  isDisabled: boolean;
}

const Controls: React.FC<ControlsProps> = ({ contentType, setContentType, onGenerate, isLoading, isDisabled }) => {
  return (
    <div className="flex flex-col gap-6 p-4 bg-gray-800/50 rounded-lg border border-gray-700">
      <div>
        <label className="block text-sm font-medium text-gray-400 mb-3 text-center">
          اختر نوع المحتوى المطلوب إنشاؤه
        </label>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {CONTENT_TYPE_OPTIONS.map(option => (
            <button
              key={option.value}
              onClick={() => setContentType(option.value)}
              className={`flex flex-col items-center justify-center gap-2 p-3 rounded-lg border-2 transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900
                ${contentType === option.value
                  ? 'bg-cyan-600 border-cyan-500 text-white shadow-lg'
                  : 'bg-gray-700/50 border-gray-600 hover:bg-gray-700 hover:border-cyan-500 text-gray-300'
                }`}
            >
              <span className="text-3xl" role="img" aria-label={option.label}>{option.emoji}</span>
              <span className="text-xs font-semibold">{option.label}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="w-full">
        <button
          onClick={onGenerate}
          disabled={isLoading || isDisabled}
          className="w-full h-12 px-6 py-2 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 focus:ring-offset-gray-900 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center transform hover:scale-105"
        >
          {isLoading ? (
            <LoadingIndicator />
          ) : (
            <>
              <span className="mr-2" role="img" aria-label="rocket">🚀</span>
              إنشاء المقالات
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default Controls;