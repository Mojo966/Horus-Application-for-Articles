import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="w-full mt-auto py-6 bg-gray-800 border-t border-gray-700 text-center text-gray-400">
            <div className="container mx-auto px-4 flex flex-col items-center gap-2">
                
                <p className="text-sm">
                    &copy; {new Date().getFullYear()} - تطوير وانتاج شركة حورس إچيبت للتطوير البرمجي. جميع الحقوق محفوظة.
                </p>
                
                <p className="text-xs font-semibold">
                    <span>مدير الشركة: د. محمد الجندي</span>
                    <span className="mx-3 text-gray-600">|</span>
                    <span>رئيس التحرير: أ. قدر يحيى</span>
                </p>
            </div>
        </footer>
    );
};

export default Footer;
