
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="py-4 px-8 bg-gray-800 border-b border-gray-700">
      <h1 className="text-2xl font-bold text-cyan-400 tracking-wider text-center sm:text-right">
        أداة حورس للمقالات المخصصة
      </h1>
    </header>
  );
};

export default Header;
