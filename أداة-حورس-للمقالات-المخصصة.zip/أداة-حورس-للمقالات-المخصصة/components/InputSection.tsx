
import React from 'react';

interface InputSectionProps {
  rawInput: string;
  setRawInput: (input: string) => void;
}

const InputSection: React.FC<InputSectionProps> = ({ rawInput, setRawInput }) => {
  return (
    <div className="flex flex-col h-full">
      <label htmlFor="rawInput" className="block text-sm font-medium text-gray-400 mb-2">
        أدخل بيانات المقال هنا (بروتوكول Perplexity)
      </label>
      <textarea
        id="rawInput"
        rows={10}
        value={rawInput}
        onChange={(e) => setRawInput(e.target.value)}
        placeholder="ARTICLE TITLE 1: ..."
        className="flex-grow w-full bg-gray-900/50 border border-gray-700 rounded-md shadow-sm p-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 text-gray-200 resize-none font-mono text-sm"
      />
    </div>
  );
};

export default InputSection;
