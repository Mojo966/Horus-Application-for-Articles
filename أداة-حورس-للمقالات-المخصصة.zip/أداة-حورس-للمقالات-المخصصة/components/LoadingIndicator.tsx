import React from 'react';

const LoadingIndicator: React.FC = () => {
  const barBaseStyle: React.CSSProperties = {
    animation: `sound 1.2s ease-in-out infinite`,
    width: '4px',
    backgroundColor: '#22d3ee', // tailwind cyan-400
    display: 'inline-block'
  };

  return (
    <div className="flex items-end justify-center space-x-1 h-6">
      <style>{`
        @keyframes sound {
          0%, 100% { height: 4px; }
          50% { height: 24px; }
        }
      `}</style>
      <div style={{ ...barBaseStyle, animationDelay: '0s' }}></div>
      <div style={{ ...barBaseStyle, animationDelay: '0.2s' }}></div>
      <div style={{ ...barBaseStyle, animationDelay: '0.4s' }}></div>
      <div style={{ ...barBaseStyle, animationDelay: '0.6s' }}></div>
      <div style={{ ...barBaseStyle, animationDelay: '0.8s' }}></div>
    </div>
  );
};

export default LoadingIndicator;
