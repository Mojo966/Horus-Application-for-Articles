import React, { useState, useCallback } from 'react';
import { GeneratedArticle } from '../types';
import LoadingIndicator from './LoadingIndicator';
import { editImage } from '../services/geminiService';
import { fileToImageObject } from '../utils/file';

interface CopyableInfoBoxProps {
    label: string;
    value: string;
    isCodeBlock?: boolean;
}

const CopyableInfoBox: React.FC<CopyableInfoBoxProps> = ({ label, value, isCodeBlock = false }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(value);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div>
            <label className="block text-xs font-medium text-gray-400 mb-1">{label}</label>
            <div className="flex items-start gap-2">
                 {isCodeBlock ? (
                    <textarea
                        readOnly
                        className="flex-grow bg-gray-900/70 p-2 rounded-md text-xs text-cyan-300 h-32 resize-y w-full font-mono"
                        value={value}
                    />
                ) : (
                    <pre className="flex-grow bg-gray-900/70 p-2 rounded-md text-xs text-cyan-300 whitespace-pre-wrap break-all">
                        <code>{value}</code>
                    </pre>
                )}
                <button
                    onClick={handleCopy}
                    className="px-3 py-2 text-xs rounded-md bg-gray-600 hover:bg-gray-500 text-white transition-colors flex-shrink-0"
                    aria-label={`Copy ${label}`}
                >
                    {copied ? '✔' : '📋'}
                </button>
            </div>
        </div>
    );
};

const ImageEditor: React.FC<{
    article: GeneratedArticle;
    onImageUpdate: (articleId: number, newImageUrl: string) => void;
    setError: (error: string | null) => void;
}> = ({ article, onImageUpdate, setError }) => {
    const [prompt, setPrompt] = useState('');
    const [uploadedImages, setUploadedImages] = useState<{ data: string; mimeType: string; name: string }[]>([]);
    const [isEditing, setIsEditing] = useState(false);

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            try {
                const files = Array.from(event.target.files);
                const imageObjects = await Promise.all(files.map(fileToImageObject));
                setUploadedImages(prev => [...prev, ...imageObjects]);
            } catch (error) {
                console.error("Error processing file upload:", error);
                setError("Failed to read uploaded image.");
            }
        }
    };
    
    const handleRemoveImage = (imageName: string) => {
        setUploadedImages(prev => prev.filter(img => img.name !== imageName));
    };

    const handleEditImage = async () => {
        setIsEditing(true);
        setError(null);
        try {
            const originalImageMimeType = article.imageUrl.split(';')[0].split(':')[1];
            const originalImageData = article.imageUrl.split(',')[1];

            const baseImages = [
                { data: originalImageData, mimeType: originalImageMimeType },
                ...uploadedImages
            ];

            const newImageUrl = await editImage(baseImages, prompt);
            onImageUpdate(article.id, newImageUrl);
            setPrompt(''); // Clear prompt on success
            setUploadedImages([]); // Clear uploaded images
        } catch (e: any) {
            console.error("Image editing failed:", e);
            setError(`Image editing failed: ${e.message}`);
        } finally {
            setIsEditing(false);
        }
    };
    
    const handleDownloadImage = () => {
        const link = document.createElement('a');
        link.href = article.imageUrl;
        link.download = `${article.slug || 'edited-image'}.webp`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="p-4 space-y-4">
            <h4 className="text-sm font-bold text-gray-400 mb-2 text-center">محرر الصور</h4>
            <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-shrink-0 lg:w-1/2 space-y-3 flex flex-col items-center">
                    <p className="text-xs text-center text-gray-500">الصورة الحالية</p>
                    <img src={article.imageUrl} alt={article.title} className="rounded-lg max-w-full h-auto border-2 border-gray-600" />
                     <button onClick={handleDownloadImage} className="w-full px-3 py-2 text-sm rounded-md bg-green-600 text-white hover:bg-green-700 transition-colors">تحميل الصورة الحالية</button>
                </div>
                <div className="flex-grow space-y-3">
                     <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="اكتب وصفاً للتعديل المطلوب (مثال: أضف تأثير غروب الشمس) أو ادمج مع الصور المرفوعة..."
                        rows={4}
                        className="w-full bg-gray-900/70 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-cyan-500 text-gray-200 text-sm"
                    />
                    <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1">
                          ارفع صور للدمج أو الإلهام (اختياري)
                        </label>
                        <input type="file" multiple accept="image/*" onChange={handleFileChange} className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-gray-600 file:text-cyan-300 hover:file:bg-gray-500"/>
                    </div>
                    {uploadedImages.length > 0 && (
                        <div className="space-y-2 p-2 border border-gray-700 rounded-md">
                            <p className="text-xs text-gray-400">الصور المرفوعة:</p>
                            <div className="flex flex-wrap gap-2">
                                {uploadedImages.map((img, idx) => (
                                    <div key={idx} className="relative">
                                        <img src={`data:${img.mimeType};base64,${img.data}`} alt={img.name} className="w-16 h-16 object-cover rounded"/>
                                        <button onClick={() => handleRemoveImage(img.name)} className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full text-xs w-5 h-5 flex items-center justify-center font-bold">X</button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    <button onClick={handleEditImage} disabled={isEditing} className="w-full h-10 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center">
                        {isEditing ? <LoadingIndicator /> : '✨ تحديث الصورة'}
                    </button>
                </div>
            </div>
        </div>
    );
};


const OutputArticle: React.FC<{
    article: GeneratedArticle;
    onImageUpdate: (articleId: number, newImageUrl: string) => void;
    setError: (error: string | null) => void;
}> = ({ article, onImageUpdate, setError }) => {
    const [activeTab, setActiveTab] = useState<'preview' | 'editor'>('preview');

    const handleDownloadArticle = () => {
        const fileContent = `[SLUG]\n${article.slug}\n\n[META DESCRIPTION]\n${article.metaDescription}\n\n--- HTML CONTENT BELOW ---\n\n${article.html}`;
        
        const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${article.title}.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const previewHtml = article.html.replace(/__GENERATED_IMAGE_URL__/g, article.imageUrl);

    return (
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg overflow-hidden">
            <div className="p-3 bg-gray-800 flex justify-between items-center border-b border-gray-700 gap-4">
                <h3 className="font-semibold text-cyan-400 truncate pr-4 flex-1">{article.title}</h3>
                <div className="flex items-center gap-2 flex-shrink-0">
                    <button onClick={handleDownloadArticle} className="px-3 py-1 text-xs rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors">تحميل المقال (txt.)</button>
                </div>
            </div>

            <div className="border-b border-gray-700 bg-gray-800 flex">
                <button 
                    onClick={() => setActiveTab('preview')}
                    className={`flex-1 py-2 text-sm font-semibold transition-colors ${activeTab === 'preview' ? 'bg-gray-700 text-cyan-400' : 'text-gray-400 hover:bg-gray-700/50'}`}
                >
                    معاينة المقال
                </button>
                <button 
                    onClick={() => setActiveTab('editor')}
                    className={`flex-1 py-2 text-sm font-semibold transition-colors ${activeTab === 'editor' ? 'bg-gray-700 text-cyan-400' : 'text-gray-400 hover:bg-gray-700/50'}`}
                >
                    محرر الصور
                </button>
            </div>
            
            <div className="h-[450px] overflow-y-auto">
                {activeTab === 'preview' ? (
                    <div className="p-4">
                      <div className="prose prose-invert max-w-none preview-container" dangerouslySetInnerHTML={{ __html: previewHtml }} />
                    </div>
                ) : (
                    <ImageEditor article={article} onImageUpdate={onImageUpdate} setError={setError} />
                )}
            </div>

            <div className="p-3 bg-gray-800/60 space-y-4 border-t border-gray-700">
              <CopyableInfoBox label="الوصف التعريفي (SEO)" value={article.metaDescription} />
              <CopyableInfoBox label="الرابط المخصص (Slug)" value={article.slug} />
              <CopyableInfoBox label="كود المقال الكامل (HTML)" value={article.html} isCodeBlock />
            </div>
        </div>
    );
};

interface OutputSectionProps {
  articles: GeneratedArticle[];
  isLoading: boolean;
  onImageUpdate: (articleId: number, newImageUrl: string) => void;
  setError: (error: string | null) => void;
}

const OutputSection: React.FC<OutputSectionProps> = ({ articles, isLoading, onImageUpdate, setError }) => {
  return (
    <div className="flex flex-col h-full">
      <h2 className="text-sm font-medium text-gray-400 mb-2">النتائج</h2>
       <div className="flex-grow bg-gray-900/50 border border-gray-700 rounded-lg p-4 space-y-4 overflow-y-auto">
        {isLoading && (
          <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
            <LoadingIndicator />
            <p className="text-cyan-400 font-semibold">...جاري الإنتاج 👍😁</p>
            <p className="text-gray-500 text-sm">يقوم الذكاء الاصطناعي الآن بكتابة وتصميم المحتوى</p>
          </div>
        )}
        {!isLoading && articles.length === 0 && <p className="text-center text-gray-500">سيتم عرض المقالات التي تم إنشاؤها هنا</p>}
        {articles.map(article => <OutputArticle key={article.id} article={article} onImageUpdate={onImageUpdate} setError={setError} />)}
       </div>
    </div>
  );
};

export default OutputSection;