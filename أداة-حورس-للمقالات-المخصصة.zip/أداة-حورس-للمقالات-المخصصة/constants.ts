import { ContentType } from './types';

export const CONTENT_TYPE_OPTIONS = [
  { value: ContentType.News, label: "الأخبار", emoji: "📰" },
  { value: ContentType.SportsMedicine, label: "الطب الرياضي", emoji: "⚕️" },
  { value: ContentType.AlternativeMedicine, label: "الطب البديل", emoji: "🌿" },
  { value: ContentType.Beauty, label: "الجمال والمرأة", emoji: "💄" },
  { value: ContentType.Cooking, label: "الطبخ", emoji: "🍳" },
  { value: ContentType.Horoscope, label: "الأبراج", emoji: "✨" },
  { value: ContentType.Tech, label: "التقنية والتدوين", emoji: "💻" },
];

export const API_KEY_ERROR_MESSAGE = "API_KEY environment variable not set. Please set it to use the AI features.";