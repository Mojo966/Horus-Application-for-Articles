import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ParsedArticle, ContentType, GeneratedArticle } from '../types';
import { convertToWebp } from "../utils/image";

if (!process.env.API_KEY) {
    console.error("API_KEY environment variable not set.");
}
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

function getArticleRewritePrompt(article: ParsedArticle, contentType: ContentType): string {
    return `
You are SHADOWHACKER-GOD, an expert content writer and SEO specialist. Your task is to take the following raw text and expand it into a comprehensive, 100% unique, and engaging article of at least 1000 words in Arabic.

**Article Title:** "${article.title}"
**Content Topic:** ${contentType}

**Formatting Rules (Follow PRECISELY):**
1.  **Structure:** Use an introduction, several subheadings (H3), and a conclusion.
2.  **Paragraphs & Spacing:**
    *   Wrap EVERY paragraph in its own \`<div style="text-align: right;">...\</div>\`.
    *   After each paragraph \`</div>\` and each subheading \`</h3>\`, add a line break div: \`<div style="text-align: right;"><br /></div>\`.
3.  **Subheadings:** Format subheadings exactly as: \`<h3 style="text-align: right;"><span style="font-size: large;">Subheading Text</span></h3>\`.
4.  **Citations:** The user provided these sources: ${JSON.stringify(article.sources)}. You MUST insert citation links throughout the text where appropriate. Format the links exactly like this: \`<a href="#ref1" id="cite1" style="color:#2196f3; font-weight:bold; text-decoration:none;">[1]</a>\`, \`<a href="#ref2" id="cite2" ...>[2]</a>\`, etc. Distribute them naturally.
5.  **Blockquote:** After the second main paragraph, identify the single most impactful sentence from the article text and wrap it in this exact HTML, placed inside its own paragraph div: \`<div style="text-align: right;"><blockquote class="tr_bq">"The sentence here"</blockquote></div>\`.
6.  **"More" Tag:** Inside the second paragraph's \`<div>\`, after the text content, add this exact span: \`<span><!--more--></span>\`.
7.  **Language:** Write in professional, fluent, and eloquent Arabic.
8.  **Output:** Provide ONLY the HTML for the article body. Start with the first paragraph's \`<div>\` and end with the last. DO NOT include meta tags, the main H3 title, image table, sources section, or QA schema.

**Raw Text to Expand:**
---
${article.text}
---
`;
}

function getSEOMetadataPrompt(articleText: string, articleTitle: string): string {
    return `
Based on the following Arabic article text and title, generate SEO metadata.

**Article Title:** ${articleTitle}
**Article Text:**
---
${articleText}
---

**Instructions:**
1.  **Meta Description:** Write a compelling and concise meta description in Arabic, under 160 characters. It should summarize the article and entice users to click.
2.  **Keywords:** Provide a comma-separated list of 7-10 relevant keywords in Arabic that accurately reflect the main topics of the article.
3.  **Slug:** Create a short, SEO-friendly, URL-safe slug in **English**. First, translate the Arabic title to English, then create the slug. Use hyphens (-) instead of spaces. For example, if the title is "فوائد الشاي الأخضر", the slug should be "green-tea-benefits".

**Output:**
Provide ONLY a valid JSON object with three keys: "description", "keywords", and "slug".
`;
}


function getQASchemaPrompt(generatedArticleText: string): string {
  return `
Based on the following Arabic article text, generate content for a Q&A section.

**Task:**
Generate one main question with its answer, and four sub-questions with their answers.

**Rules:**
1.  All questions and answers must be in Arabic and derived from the provided text.
2.  The main question should cover the central topic of the article.
3.  The sub-questions should cover specific details.
4.  Your output must be **only** a valid JSON object that strictly adheres to the schema requested by the API call. It should contain keys for 'mainQuestion', 'mainAnswer', and 'subQuestions'.

**Article Text:**
---
${generatedArticleText}
---
`;
}

export async function generateArticleContent(article: ParsedArticle, contentType: ContentType): Promise<Omit<GeneratedArticle, 'id' | 'title'>> {
  // Generate a unique image for the article as JPEG
  const imagePrompt = `A high-quality, photorealistic image representing the news article titled: "${article.title}". The image should be professional, visually appealing, and suitable for a news website. 16:9 aspect ratio. Avoid text and logos.`;
  const imageResponse = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: imagePrompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '16:9',
      },
  });
  const base64ImageBytes = imageResponse.generatedImages[0].image.imageBytes;
  const jpegImageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;

  // Convert the generated JPEG to WebP
  const webpImageUrl = await convertToWebp(jpegImageUrl);

  // Rewrite the article text
  const rewritePrompt = getArticleRewritePrompt(article, contentType);
  const textResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: rewritePrompt,
  });
  const rewrittenText = textResponse.text;

  // Generate SEO Metadata
  const seoPrompt = getSEOMetadataPrompt(rewrittenText, article.title);
  const seoResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: seoPrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            description: { type: Type.STRING, description: "A compelling and concise meta description in Arabic, under 160 characters." },
            keywords: { type: Type.STRING, description: "A comma-separated list of 7-10 relevant keywords in Arabic." },
            slug: { type: Type.STRING, description: "A short, SEO-friendly, URL-safe slug in English, with words separated by hyphens." }
          }
        }
      }
  });
  let metaDescription = rewrittenText.substring(0, 155).replace(/"/g, '&quot;') + '...';
  let metaKeywords = `${contentType}, ${article.title.split(' ').join(', ')}`;
  let slug = article.title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '');
  
  try {
    const parsedSeo = JSON.parse(seoResponse.text);
    metaDescription = parsedSeo.description.replace(/"/g, '&quot;');
    metaKeywords = parsedSeo.keywords;
    slug = parsedSeo.slug;
  } catch (e) {
    console.error("Failed to parse SEO metadata JSON", e);
  }

  const sourcesHtml = `
    <h3 style="text-align: right;"><span style="font-size: large;">المصادر</span></h3>
    <div style="text-align: right;">
        <ul style="list-style: none; padding: 0px;">
            ${article.sources.map((source, index) => `
                <li id="ref${index + 1}" style="margin-bottom: 8px; direction: rtl;">
                    <a href="#cite${index + 1}" style="color:inherit; font-weight:normal; text-decoration:none;" title="اذهب لمكان الاقتباس في النص">[${index + 1}]</a>
                    - <a href="${source.url}" rel="noopener noreferrer nofollow" style="color:#2196f3; text-decoration:underline;" target="_blank" title="${source.title}">${source.title}</a>
                </li>
            `).join('')}
        </ul>
    </div>`;

  const qaPrompt = getQASchemaPrompt(rewrittenText);
   const qaResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: qaPrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                mainQuestion: { type: Type.STRING, description: "The main question covering the central topic of the article." },
                mainAnswer: { type: Type.STRING, description: "The answer to the main question." },
                subQuestions: {
                    type: Type.ARRAY,
                    description: "An array of four sub-questions and their answers.",
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            question: { type: Type.STRING, description: "A specific sub-question derived from the article." },
                            answer: { type: Type.STRING, description: "The answer to the specific sub-question." },
                        }
                    }
                }
            }
        }
    }
  });

  let qaSchemaJson = {};
  try {
      const parsedResponse = JSON.parse(qaResponse.text);
      qaSchemaJson = {
          "@context": "https://schema.org",
          "@type": "QAPage",
          "mainEntity": {
              "@type": "Question",
              "name": article.title,
              "text": parsedResponse.mainQuestion,
              "datePublished": "__POST_DATE__",
              "dateModified": "__POST_MODIFIED_DATE__",
              "author": { "@type": "Person", "name": "__AUTHOR_NAME__", "url": "__AUTHOR_URL__" },
              "answerCount": 1,
              "acceptedAnswer": {
                  "@type": "Answer",
                  "text": parsedResponse.mainAnswer,
                  "datePublished": "__POST_DATE__",
                  "dateModified": "__POST_MODIFIED_DATE__",
                  "url": "__POST_URL__",
                  "author": { "@type": "Person", "name": "__AUTHOR_NAME__", "url": "__AUTHOR_URL__" }
              }
          },
          "hasPart": parsedResponse.subQuestions.map((sq: {question: string, answer: string}) => ({
              "@type": "Question",
              "text": sq.question,
              "datePublished": "__POST_DATE__",
              "dateModified": "__POST_MODIFIED_DATE__",
              "answerCount": 1,
              "author": { "@type": "Person", "name": "__AUTHOR_NAME__", "url": "__AUTHOR_URL__" },
              "acceptedAnswer": {
                  "@type": "Answer",
                  "text": sq.answer,
                   "datePublished": "__POST_DATE__",
                   "dateModified": "__POST_MODIFIED_DATE__",
                   "url": "__POST_URL__",
                   "author": { "@type": "Person", "name": "__AUTHOR_NAME__", "url": "__AUTHOR_URL__" }
              }
          }))
      };
  } catch(e) {
      console.error("Failed to parse QA schema JSON", e);
  }

  const qaSchemaHtml = `<script id="qaData" type="application/ld+json">${JSON.stringify(qaSchemaJson, null, 2)}</script>`;

  const imageTableHtml = `<!-- 
      IMPORTANT: The image src below is a placeholder. 
      For best results:
      1. Save the generated image from the 'Preview' tab.
      2. Upload it to your hosting service (e.g., Blogger, Wordpress).
      3. Replace "__GENERATED_IMAGE_URL__" below with the new URL for your uploaded image.
    -->
    <table align="center" cellpadding="0" cellspacing="0" class="tr-caption-container" style="margin-left: auto; margin-right: auto;">
    <tbody>
    <tr>
    <td style="text-align: center;">
    <a href="__GENERATED_IMAGE_URL__" imageanchor="1" style="margin-left: auto; margin-right: auto;">
    <img alt="${article.title}" border="0" data-original-height="900" data-original-width="1600" height="360" src="__GENERATED_IMAGE_URL__" title="${article.title}" width="640" />
    </a>
    </td>
    </tr>
    <tr>
    <td class="tr-caption" style="text-align: center;">${article.title}</td>
    </tr>
    </tbody>
    </table>`;

  const finalHtml = `<!-- بيانات الميتا للمقال (SEO Meta Data) -->
<meta content="${article.title}" name="headline" />
<meta content="${article.title}" property="og:title" />
<meta content="${metaKeywords}" name="keywords" />
<meta content="${metaDescription}" name="description" />

<!-- العنوان الرئيسي للمقال -->
<h3 style="text-align: right;"><span style="font-size: large;">${article.title}</span></h3>
<div style="text-align: right;"><br /></div>

${imageTableHtml}

<div style="text-align: center;"><br /></div>

${rewrittenText}

<div style="text-align: right;"><br /></div>

${sourcesHtml}
    
${qaSchemaHtml}
  `;

  return { html: finalHtml, imageUrl: webpImageUrl, metaDescription, metaKeywords, slug };
}

export async function editImage(
  baseImages: { data: string; mimeType: string }[],
  prompt: string
): Promise<string> {
  if (!prompt && baseImages.length <= 1) {
    throw new Error("An editing prompt or multiple images are required to generate a new image.");
  }
  
  const imageParts = baseImages.map(img => ({
    inlineData: {
      data: img.data,
      mimeType: img.mimeType,
    },
  }));

  const textPart = { text: prompt };

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image-preview',
    contents: {
      parts: [...imageParts, textPart],
    },
    config: {
      responseModalities: [Modality.IMAGE, Modality.TEXT],
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      const base64ImageBytes: string = part.inlineData.data;
      const imageUrl = `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
      // Convert to WebP for consistency and performance
      return await convertToWebp(imageUrl);
    }
  }

  throw new Error("The AI did not return an image. It may have responded with text instead. Check the console for the full response.");
}
