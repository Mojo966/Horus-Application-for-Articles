export enum ContentType {
  News = "الأخبار",
  SportsMedicine = "الطب الرياضي",
  AlternativeMedicine = "الطب البديل",
  Beauty = "الجمال والمرأة",
  Cooking = "الطبخ",
  Horoscope = "الأبراج",
  Tech = "التقنية والتدوين",
}

export interface ParsedArticle {
  title: string;
  imageUrl: string;
  text: string;
  sources: { title: string; url: string }[];
}

export interface GeneratedArticle {
  id: number;
  html: string;
  title: string;
  imageUrl: string;
  metaDescription: string;
  metaKeywords: string;
  slug: string;
}
