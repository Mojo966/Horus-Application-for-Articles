/**
 * Reads a File object and converts it into a base64 data object.
 * @param file The File object from an input element.
 * @returns A promise that resolves with an object containing the base64 data, mime type, and original file name.
 */
export function fileToImageObject(file: File): Promise<{ data: string; mimeType: string; name: string; }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(',')[1];
      resolve({ data: base64Data, mimeType: file.type, name: file.name });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
