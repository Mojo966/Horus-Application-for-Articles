/**
 * Converts an image data URL (e.g., JPEG, PNG) to a WebP data URL using a canvas.
 * @param imageDataUrl The base64 data URL of the source image.
 * @returns A promise that resolves with the base64 data URL of the WebP image.
 */
export function convertToWebp(imageDataUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();

    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        return reject(new Error('Could not get 2D context from canvas.'));
      }

      ctx.drawImage(img, 0, 0);
      
      // Convert the canvas content to a WebP data URL.
      // The second parameter is the quality, ranging from 0 to 1. 
      // 0.9 provides a good balance between quality and file size.
      const webpDataUrl = canvas.toDataURL('image/webp', 0.9);
      resolve(webpDataUrl);
    };

    img.onerror = (error) => {
      console.error("Error loading image for conversion:", error);
      reject(new Error('Failed to load the image for conversion.'));
    };

    img.src = imageDataUrl;
  });
}
