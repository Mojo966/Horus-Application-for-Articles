
import { ParsedArticle } from '../types';

export function parseRawInput(rawText: string): ParsedArticle[] {
  if (!rawText.trim()) {
    return [];
  }

  const articles: ParsedArticle[] = [];
  const articleBlocks = rawText.split(/ARTICLE TITLE \d+:/).filter(block => block.trim() !== '');

  for (const block of articleBlocks) {
    const lines = block.trim().split('\n');
    const title = lines[0].trim();

    const imageUrlLine = lines.find(line => line.startsWith('الصورة الرئيسية للمقال'));
    const imageUrl = imageUrlLine ? imageUrlLine.split(': ')[1]?.trim() : '';
    
    const textStartIndex = lines.findIndex(line => line.startsWith('نص المقال الكامل من المصدر:'));
    const sourcesStartIndex = lines.findIndex(line => line.startsWith('المصادر في الوقت الفعلي للموضوع'));

    let text = '';
    if (textStartIndex !== -1) {
        const textEndIndex = sourcesStartIndex !== -1 ? sourcesStartIndex : lines.length;
        text = lines.slice(textStartIndex + 1, textEndIndex).join('\n').trim();
    }

    const sources: { title: string; url: string }[] = [];
    if (sourcesStartIndex !== -1) {
        const sourceLines = lines.slice(sourcesStartIndex + 1);
        for (const line of sourceLines) {
            // FIX: Corrected regex to properly parse " [1] Title - URL " format.
            const match = line.match(/\[\d+\]\s*(.*)\s+-\s+(https?:\/\/\S+)/);
            if (match) {
                sources.push({ title: match[1].trim(), url: match[2].trim() });
            }
        }
    }
    
    articles.push({ title, imageUrl, text, sources });
  }

  return articles;
}